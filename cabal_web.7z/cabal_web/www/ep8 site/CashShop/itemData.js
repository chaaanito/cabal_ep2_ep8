const itemData = [
    {
        "value": "687",
        "itemidx": "687",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Thunder_Disc_lvl_1_2_3.webp",
        "label": "Thunder Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "687",
        "itemidx": "687",
        "itemopt": "266",
        "img": "\/CashShop\/items\/Thunder_Disc_lvl_1_2_3.webp",
        "label": "Thunder Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "687",
        "itemidx": "687",
        "itemopt": "394",
        "img": "\/CashShop\/items\/Thunder_Disc_lvl_1_2_3.webp",
        "label": "Thunder Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "687",
        "itemidx": "687",
        "itemopt": "522",
        "img": "\/CashShop\/items\/Thunder_Disc_lvl_1_2_3.webp",
        "label": "Thunder Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "688",
        "itemidx": "688",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Bloody_Disc_lvl_1_2_3.webp",
        "label": "Bloody Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "688",
        "itemidx": "688",
        "itemopt": "266",
        "img": "\/CashShop\/items\/Bloody_Disc_lvl_1_2_3.webp",
        "label": "Bloody Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "688",
        "itemidx": "688",
        "itemopt": "394",
        "img": "\/CashShop\/items\/Bloody_Disc_lvl_1_2_3.webp",
        "label": "Bloody Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "688",
        "itemidx": "688",
        "itemopt": "522",
        "img": "\/CashShop\/items\/Bloody_Disc_lvl_1_2_3.webp",
        "label": "Bloody Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "690",
        "itemidx": "690",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Aqua_Disc_lvl_1_2_3.webp",
        "label": "Aqua Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "690",
        "itemidx": "690",
        "itemopt": "266",
        "img": "\/CashShop\/items\/Aqua_Disc_lvl_1_2_3.webp",
        "label": "Aqua Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "690",
        "itemidx": "690",
        "itemopt": "394",
        "img": "\/CashShop\/items\/Aqua_Disc_lvl_1_2_3.webp",
        "label": "Aqua Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "690",
        "itemidx": "690",
        "itemopt": "522",
        "img": "\/CashShop\/items\/Aqua_Disc_lvl_1_2_3.webp",
        "label": "Aqua Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "689",
        "itemidx": "689",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Earth_Disc_lvl_1_2_3.webp",
        "label": "Earth Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "689",
        "itemidx": "689",
        "itemopt": "266",
        "img": "\/CashShop\/items\/Earth_Disc_lvl_1_2_3.webp",
        "label": "Earth Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "689",
        "itemidx": "689",
        "itemopt": "394",
        "img": "\/CashShop\/items\/Earth_Disc_lvl_1_2_3.webp",
        "label": "Earth Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "689",
        "itemidx": "689",
        "itemopt": "522",
        "img": "\/CashShop\/items\/Earth_Disc_lvl_1_2_3.webp",
        "label": "Earth Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "691",
        "itemidx": "691",
        "itemopt": "138",
        "img": "\/CashShop\/items\/soul_disc_1_2_3.webp",
        "label": "Soul Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "691",
        "itemidx": "691",
        "itemopt": "266",
        "img": "\/CashShop\/items\/soul_disc_1_2_3.webp",
        "label": "Soul Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "691",
        "itemidx": "691",
        "itemopt": "394",
        "img": "\/CashShop\/items\/soul_disc_1_2_3.webp",
        "label": "Soul Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "691",
        "itemidx": "691",
        "itemopt": "522",
        "img": "\/CashShop\/items\/soul_disc_1_2_3.webp",
        "label": "Soul Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "686",
        "itemidx": "686",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Air_Disc_lvl_1_2_3.webp",
        "label": "Air Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "686",
        "itemidx": "686",
        "itemopt": "266",
        "img": "\/CashShop\/items\/Air_Disc_lvl_1_2_3.webp",
        "label": "Air Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "686",
        "itemidx": "686",
        "itemopt": "394",
        "img": "\/CashShop\/items\/Air_Disc_lvl_1_2_3.webp",
        "label": "Air Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "686",
        "itemidx": "686",
        "itemopt": "522",
        "img": "\/CashShop\/items\/Air_Disc_lvl_1_2_3.webp",
        "label": "Air Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "685",
        "itemidx": "685",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Holy_disc_lvl_1_2_3.webp",
        "label": "Holy Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "685",
        "itemidx": "685",
        "itemopt": "266",
        "img": "\/CashShop\/items\/Holy_disc_lvl_1_2_3.webp",
        "label": "Holy Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "685",
        "itemidx": "685",
        "itemopt": "394",
        "img": "\/CashShop\/items\/Holy_disc_lvl_1_2_3.webp",
        "label": "Holy Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "685",
        "itemidx": "685",
        "itemopt": "522",
        "img": "\/CashShop\/items\/Holy_disc_lvl_1_2_3.webp",
        "label": "Holy Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "684",
        "itemidx": "684",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Dark_Disc_lvl_1_2_3.webp",
        "label": "Dark Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "684",
        "itemidx": "684",
        "itemopt": "266",
        "img": "\/CashShop\/items\/Dark_Disc_lvl_1_2_3.webp",
        "label": "Dark Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "684",
        "itemidx": "684",
        "itemopt": "394",
        "img": "\/CashShop\/items\/Dark_Disc_lvl_1_2_3.webp",
        "label": "Dark Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "684",
        "itemidx": "684",
        "itemopt": "522",
        "img": "\/CashShop\/items\/Dark_Disc_lvl_1_2_3.webp",
        "label": "Dark Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "683",
        "itemidx": "683",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Flame_Disc_lvl_1_2_3.webp",
        "label": "Flame Disc(Lvl 1) 10pcs",
        "price": "5"
    },
    {
        "value": "683",
        "itemidx": "683",
        "itemopt": "266",
        "img": "\/CashShop\/items\/Flame_Disc_lvl_1_2_3.webp",
        "label": "Flame Disc(Lvl 2) 10pcs",
        "price": "5"
    },
    {
        "value": "683",
        "itemidx": "683",
        "itemopt": "394",
        "img": "\/CashShop\/items\/Flame_Disc_lvl_1_2_3.webp",
        "label": "Flame Disc(Lvl 3) 10pcs",
        "price": "5"
    },
    {
        "value": "683",
        "itemidx": "683",
        "itemopt": "522",
        "img": "\/CashShop\/items\/Flame_Disc_lvl_1_2_3.webp",
        "label": "Flame Disc(Lvl 4) 10pcs",
        "price": "5"
    },
    {
        "value": "607",
        "itemidx": "607",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Pherystin_Quartz_Core.webp",
        "label": "Quartz Core(Pherystin) 10pcs",
        "price": "5"
    },
    {
        "value": "608",
        "itemidx": "608",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Aqua_Quartz_Core.webp",
        "label": "Quartz Core(Aqua) 10pcs",
        "price": "5"
    },
    {
        "value": "609",
        "itemidx": "609",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Lapiz_quartz_core.webp",
        "label": "Quartz Core(Lapis) 10pcs",
        "price": "5"
    },
    {
        "value": "610",
        "itemidx": "610",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Topaz_quartz_core.webp",
        "label": "Quartz Core(Topaz) 10pcs",
        "price": "5"
    },
    {
        "value": "618",
        "itemidx": "618",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Titanium_Material_Core.webp",
        "label": "Material Core(Titanium) 10pcs",
        "price": "5"
    },
    {
        "value": "619",
        "itemidx": "619",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Shadowtitanium_material_core.webp",
        "label": "Material Core(Shadowtitanium) 10pcs",
        "price": "5"
    },
    {
        "value": "620",
        "itemidx": "620",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Osmium_Material_Core.webp",
        "label": "Material Core(Osmium) 10pcs",
        "price": "5"
    },
    {
        "value": "621",
        "itemidx": "621",
        "itemopt": "138",
        "img": "\/CashShop\/items\/Red_Osmium_material_core.webp",
        "label": "Material Core(Redosmium) 10pcs",
        "price": "5"
    },
    {
        "value": "628",
        "itemidx": "628",
        "itemopt": "255",
        "img": "\/CashShop\/items\/Upgrade_core_piece.webp",
        "label": "Upgrade Core(Piece) 127pcs",
        "price": "5"
    },
    {
        "value": "629",
        "itemidx": "629",
        "itemopt": "255",
        "img": "\/CashShop\/items\/Force_core_piece.webp",
        "label": "Force Core(Piece) 127pcs",
        "price": "5"
    },
    {
        "value": "676",
        "itemidx": "676",
        "itemopt": "134",
        "img": "\/CashShop\/items\/Circuit_Jewel_lvl_1.webp",
        "label": "Circuit Jewel(LV 1) 6pcs",
        "price": "5"
    },
    {
        "value": "677",
        "itemidx": "677",
        "itemopt": "134",
        "img": "\/CashShop\/items\/Circuit_Jewel_lvl_2.webp",
        "label": "Circuit Jewel(LV 2) 6pcs",
        "price": "5"
    },
    {
        "value": "678",
        "itemidx": "678",
        "itemopt": "134",
        "img": "\/CashShop\/items\/Circuit_Jewel_lvl_3.webp",
        "label": "Circuit Jewel(LV 3) 6pcs",
        "price": "5"
    },
    {
        "value": "679",
        "itemidx": "679",
        "itemopt": "134",
        "img": "\/CashShop\/items\/Circuit_Jewel_lvl_4.webp",
        "label": "Circuit Jewel(LV 4) 6pcs",
        "price": "5"
    },
    {
        "value": "680",
        "itemidx": "680",
        "itemopt": "134",
        "img": "\/CashShop\/items\/Circuit_Jewel_lvl_5.webp",
        "label": "Circuit Jewel(LV 5) 6pcs",
        "price": "5"
    },
    {
        "value": "681",
        "itemidx": "681",
        "itemopt": "134",
        "img": "\/CashShop\/items\/Circuit_Jewel_lvl_6.webp",
        "label": "Circuit Jewel(LV 6) 6pcs",
        "price": "5"
    },
    {
        "value": "692",
        "itemidx": "692",
        "itemopt": "7818",
        "img": "\/CashShop\/items\/Sharp_cartridge.webp",
        "label": "Shape Cartridge Sword(Lv 1) 10pcs",
        "price": "4"
    },
    {
        "value": "692",
        "itemidx": "692",
        "itemopt": "8458",
        "img": "\/CashShop\/items\/Sharp_cartridge.webp",
        "label": "Shape Cartridge Sword(Lv 2) 10pcs",
        "price": "5"
    },
    {
        "value": "692",
        "itemidx": "692",
        "itemopt": "9098",
        "img": "\/CashShop\/items\/Sharp_cartridge.webp",
        "label": "Shape Cartridge Sword(Lv 3) 10pcs",
        "price": "5"
    },
    {
        "value": "692",
        "itemidx": "692",
        "itemopt": "9738",
        "img": "\/CashShop\/items\/Sharp_cartridge.webp",
        "label": "Shape Cartridge Sword(Lv 4) 10pcs",
        "price": "5"
    },
    {
        "value": "24745",
        "itemidx": "24745",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Aramid_Battleset.webp",
        "label": "Aramid Battle Gloves +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24835",
        "itemidx": "24835",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Aramid_Battleset.webp",
        "label": "Aramid Battle Helm +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24790",
        "itemidx": "24790",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Aramid_Battleset.webp",
        "label": "Aramid Battle Boots +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24700",
        "itemidx": "24700",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Aramid_Battleset.webp",
        "label": "Aramid Battle Suit +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24760",
        "itemidx": "24760",
        "itemopt": "184",
        "img": "\/CashShop\/items\/MT03.webp",
        "label": "Aramid Martial Gloves +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24850",
        "itemidx": "24850",
        "itemopt": "184",
        "img": "\/CashShop\/items\/MT03.webp",
        "label": "Aramid Martial helm +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24805",
        "itemidx": "24805",
        "itemopt": "184",
        "img": "\/CashShop\/items\/MT03.webp",
        "label": "Aramid Martial Boots +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24715",
        "itemidx": "24715",
        "itemopt": "184",
        "img": "\/CashShop\/items\/MT03.webp",
        "label": "Aramid Martial Suit +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24730",
        "itemidx": "24730",
        "itemopt": "184",
        "img": "\/CashShop\/items\/AM03.webp",
        "label": "S.Steel Armor Gloves +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24820",
        "itemidx": "24820",
        "itemopt": "184",
        "img": "\/CashShop\/items\/AM03.webp",
        "label": "S.Steel Armor Helm +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24775",
        "itemidx": "24775",
        "itemopt": "184",
        "img": "\/CashShop\/items\/AM03.webp",
        "label": "S.Steel Armor Boots +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24685",
        "itemidx": "24685",
        "itemopt": "184",
        "img": "\/CashShop\/items\/AM03.webp",
        "label": "S.Steel Armor Suit +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24625",
        "itemidx": "24625",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Shadowsteel_Katana.webp",
        "label": "S.Steel Katana +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24640",
        "itemidx": "24640",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Shadowsteel_Blade.webp",
        "label": "S.Steel Blade +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24670",
        "itemidx": "24670",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Shadowsteel_Great_Sword.webp",
        "label": "S.Steel Great Sword +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24655",
        "itemidx": "24655",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Shadowsteel_Daikatana.webp",
        "label": "S.Steel Daikatana +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24595",
        "itemidx": "24595",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Citrine_Orb.webp",
        "label": "Citrine Orb +3 (SSA +3%)",
        "price": "1"
    },
    {
        "value": "24610",
        "itemidx": "24610",
        "itemopt": "184",
        "img": "\/CashShop\/items\/Citrine_Crystal.webp",
        "label": "Citrine Crystal +3 (SSA +3%)",
        "price": "1"
    }
];

export default itemData;