<?php
session_start();
require 'config.php';
$loginError = '';
$loginSuccess = '';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "{CALL cabal_user_auth(?, ?)}";
    $params = array($username, $password);
    $stmt = sqlsrv_query($connAccount, $sql, $params);
    
    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }
    
    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    
    // Check for empty fake login
    if (empty($username) || empty($password)) {
        $loginStatus = "<p>Login Failed! Please try again<p>";
        $error = 'Yes';
    }
    
    // Check if login is correct
    if (empty($row['usernum'])) {
        $loginStatus = "<p>Login Failed! Please try again<p>";
        $error = 'Yes';
    }
    
    // If all is OK
    if (!isset($error)) {
        // Store username and usernum in session
        $_SESSION['username'] = $username;
        $_SESSION['usernum'] = $row['usernum'];
        $loginSuccess = "<p>Login Successful!</p>";
    
        // Redirect to dashboard page
        header("Location: dashboard.php");
        exit();
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ωrigin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<nav class="navbar navbar-expand-lg  bg-transparent">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">ORIGIN</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link" aria-current="page" href="index.php">Home</a>
                <a class="nav-link" href="downloads.php">DOWNLOADS</a>
                <a class="nav-link" href="register.php">REGISTER</a>
            </div>
        </div>
    </div>
</nav>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4 col-md-6 col-sm-8">
            <div class="card mt-5 " id="xCard">
                <div class="card-body">
                    <h1 class="card-title">Login</h1>
                    <form method="POST">
                        <div class="mb-3">
                            <input type="text" class="form-control" id="username" name="username" required autocomplete="current-password" placeholder="username">
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password" placeholder="password">
                        </div>
                        <button type="submit" class="btn" name="login">Login</button>
                        <?php if (!empty($loginStatus)) : ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $loginStatus; ?>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($loginSuccess)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $loginSuccess; ?>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>

