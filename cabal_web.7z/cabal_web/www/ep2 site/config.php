<?php
$config = [
    'server' => '100.109.153.60',
    'username' => 'sa',
    'password' => 'Jbgj_Jbgj',
    // Databases
    'AccountDB' => 'account',
    'CabalCashDB' => 'CabalCash',
    'gameDB' => 'gamedb'
];

$serverName = $config['server'];
$connectionOptions = [
    'Uid' => $config['username'],
    'PWD' => $config['password']
];

$databaseConnections = [];
$connAccount = null;
$connCabalCash = null;
$connServer01 = null;

foreach ($config as $key => $value) {
    if (strpos($key, 'DB') !== false) {
        $databaseName = $value;
        $connectionOptions['Database'] = $databaseName;
        $connection = sqlsrv_connect($serverName, $connectionOptions);

        if ($connection === false) {
            die(print_r(sqlsrv_errors(), true));
        }

        $databaseConnections[$key] = $connection;

        // Assign connections to individual variables
        if ($key === 'AccountDB') {
            $connAccount = $connection;
        } elseif ($key === 'CabalCashDB') {
            $connCabalCash = $connection;
        } elseif ($key === 'gameDB') {
            $connServer01 = $connection;
        }
    }
}
$connAccount = $databaseConnections['AccountDB'];
$connCabalCash = $databaseConnections['CabalCashDB'];
$connServer01 = $databaseConnections['gameDB'];
?>